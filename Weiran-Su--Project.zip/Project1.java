// Weiran Su
// CSCE 314
public class Project1 
{
    public static void main(String[] args) 
    {
        Primes p = new Primes();

        MainWindow mw = new MainWindow(Config.APPLICATIONNAME, p);
    }
}
